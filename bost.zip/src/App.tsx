import React, { useState, useEffect } from 'react';
import { Activity, CheckCircle2, Zap, Server, ShieldCheck, Terminal, Copy, Check, ExternalLink, RefreshCw } from 'lucide-react';

interface EndpointInfo {
  name: string;
  method: string;
  path: string;
  description: string;
  exampleUrl: string;
}

const ENDPOINTS: EndpointInfo[] = [
  {
    name: 'Health Check',
    method: 'GET',
    path: '/api/health',
    description: 'Instant uptime, memory usage, and cache status',
    exampleUrl: '/api/health',
  },
  {
    name: 'API Directory',
    method: 'GET',
    path: '/api',
    description: 'Overview of all endpoints & whitelist specifications',
    exampleUrl: '/api',
  },
  {
    name: 'Search Songs',
    method: 'GET',
    path: '/api/search?q={query}&limit={limit}',
    description: 'Strictly songs only search with 15-min in-memory cache',
    exampleUrl: '/api/search?q=coldplay&limit=5',
  },
  {
    name: 'Home / Trending',
    method: 'GET',
    path: '/api/home',
    description: 'Curated trending and global hits cached for 30 minutes',
    exampleUrl: '/api/home',
  },
  {
    name: 'Song Details & Lyrics',
    method: 'GET',
    path: '/api/song/:id',
    description: 'Parallel metadata & lyrics fetch cached for 6 hours',
    exampleUrl: '/api/song/kJQP7kiw5Fk',
  },
  {
    name: 'Artist Songs Catalog',
    method: 'GET',
    path: '/api/artist/:id',
    description: 'All songs by artist ID with 3-hour cache',
    exampleUrl: '/api/artist/UCqECaJ8Gagnn7YCbPEzWH6g',
  },
  {
    name: 'Album Tracklist',
    method: 'GET',
    path: '/api/album/:id',
    description: 'Complete album track list and cover art with 6-hour cache',
    exampleUrl: '/api/album/MPREb_95vK9Qz1O4s',
  },
];

export default function App() {
  const [isAdmin, setIsAdmin] = useState<boolean>(() => {
    if (typeof window === 'undefined') return false;
    const params = new URLSearchParams(window.location.search);
    return params.get('admin') === 'true';
  });

  const [latency, setLatency] = useState<number | null>(null);
  const [cacheStatus, setCacheStatus] = useState<string>('Ready');
  const [activeTestUrl, setActiveTestUrl] = useState<string>('/api/health');
  const [testResult, setTestResult] = useState<any>(null);
  const [testing, setTesting] = useState(false);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  useEffect(() => {
    const handleUrlChange = () => {
      const params = new URLSearchParams(window.location.search);
      setIsAdmin(params.get('admin') === 'true');
    };

    window.addEventListener('popstate', handleUrlChange);
    return () => window.removeEventListener('popstate', handleUrlChange);
  }, []);

  useEffect(() => {
    if (isAdmin) {
      document.body.className = 'bg-neutral-950 text-neutral-100 antialiased selection:bg-neutral-800 selection:text-white admin-mode';
      document.body.style.backgroundColor = '#0a0a0a';
      document.title = 'API Running - Sonora YouTube Music REST API';
      runSpeedTest('/api/health');
    } else {
      document.body.className = 'bg-white';
      document.body.style.backgroundColor = '#ffffff';
      document.title = '';
    }
  }, [isAdmin]);

  const runSpeedTest = async (url: string = activeTestUrl) => {
    setTesting(true);
    const start = performance.now();
    try {
      const res = await fetch(url);
      const data = await res.json();
      const end = performance.now();
      const duration = Math.round(end - start);
      setLatency(duration);
      setCacheStatus(res.headers.get('X-Cache') || 'HIT');
      setTestResult(data);
    } catch (err: any) {
      setLatency(null);
      setTestResult({ error: err.message || 'Failed to connect' });
    } finally {
      setTesting(false);
    }
  };

  const copyToClipboard = (text: string, key: string) => {
    const fullUrl = text.startsWith('http') ? text : `${window.location.origin}${text}`;
    navigator.clipboard.writeText(fullUrl);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  // If not accessed with ?admin=true, render a completely blank white page
  if (!isAdmin) {
    return <div className="min-h-screen w-full bg-white" />;
  }

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100 font-sans flex flex-col justify-between selection:bg-emerald-950 selection:text-emerald-300">
      {/* Top Bar with Status */}
      <header className="border-b border-neutral-900 bg-neutral-950/80 backdrop-blur-md px-6 py-4 sticky top-0 z-50">
        <div className="max-w-5xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="relative flex h-3 w-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500"></span>
            </span>
            <span className="text-sm font-semibold tracking-wide text-neutral-200">
              Sonora API Gateway
            </span>
          </div>

          <div className="flex items-center gap-4 text-xs font-mono text-neutral-400">
            <div className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded bg-neutral-900 border border-neutral-800">
              <Zap className="w-3.5 h-3.5 text-emerald-400" />
              <span>Gzip + LRU Cache</span>
            </div>
            {latency !== null && (
              <div className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-neutral-900 border border-neutral-800 text-emerald-400">
                <Activity className="w-3.5 h-3.5" />
                <span>{latency} ms</span>
              </div>
            )}
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-5xl mx-auto w-full px-6 py-12 flex-1">
        {/* Core Hero: Simple text "API Running" */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-semibold mb-4 tracking-wider uppercase">
            <CheckCircle2 className="w-3.5 h-3.5" />
            Backend Online &amp; Optimized
          </div>
          <h1 className="text-5xl md:text-6xl font-extrabold tracking-tight text-white mb-3">
            API Running
          </h1>
          <p className="text-neutral-400 text-base md:text-lg max-w-xl mx-auto">
            High-performance, low-latency REST API service for YouTube Music songs, artist catalogs, and albums.
          </p>
        </div>

        {/* Speed & Optimization Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-10">
          <div className="p-4 rounded-xl bg-neutral-900/60 border border-neutral-800/80 flex items-start gap-3">
            <div className="p-2.5 rounded-lg bg-emerald-500/10 text-emerald-400">
              <Zap className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs font-medium text-neutral-400">Response Speed</div>
              <div className="text-lg font-bold text-white flex items-center gap-2">
                <span>{latency !== null ? `${latency} ms` : 'Testing...'}</span>
                {latency !== null && latency < 50 && (
                  <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-mono">
                    Instant
                  </span>
                )}
              </div>
              <div className="text-xs text-neutral-500 mt-0.5">X-Cache: {cacheStatus}</div>
            </div>
          </div>

          <div className="p-4 rounded-xl bg-neutral-900/60 border border-neutral-800/80 flex items-start gap-3">
            <div className="p-2.5 rounded-lg bg-blue-500/10 text-blue-400">
              <Server className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs font-medium text-neutral-400">Compression</div>
              <div className="text-lg font-bold text-white">Gzip &amp; Deflate</div>
              <div className="text-xs text-neutral-500 mt-0.5">~85% smaller JSON payloads</div>
            </div>
          </div>

          <div className="p-4 rounded-xl bg-neutral-900/60 border border-neutral-800/80 flex items-start gap-3">
            <div className="p-2.5 rounded-lg bg-purple-500/10 text-purple-400">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs font-medium text-neutral-400">Access Whitelist</div>
              <div className="text-lg font-bold text-white">Authorized Domains</div>
              <div className="text-xs text-neutral-500 mt-0.5">anaku, ytcat, fomo, gomuost, run.app</div>
            </div>
          </div>
        </div>

        {/* Live Interactive Benchmark & Tester */}
        <div className="mb-10 rounded-2xl bg-neutral-900/40 border border-neutral-800 overflow-hidden">
          <div className="px-6 py-4 border-b border-neutral-800 flex flex-wrap items-center justify-between gap-3 bg-neutral-900/60">
            <div className="flex items-center gap-2">
              <Terminal className="w-4 h-4 text-emerald-400" />
              <span className="text-sm font-semibold text-neutral-200">Live API Tester</span>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => runSpeedTest(activeTestUrl)}
                disabled={testing}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 text-xs font-medium border border-emerald-500/30 transition disabled:opacity-50 cursor-pointer"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${testing ? 'animate-spin' : ''}`} />
                <span>Test Latency</span>
              </button>
            </div>
          </div>

          <div className="p-6">
            <div className="flex flex-wrap gap-2 mb-4">
              {ENDPOINTS.slice(0, 4).map((ep) => (
                <button
                  key={ep.path}
                  onClick={() => {
                    setActiveTestUrl(ep.exampleUrl);
                    runSpeedTest(ep.exampleUrl);
                  }}
                  className={`text-xs px-3 py-1.5 rounded-lg border font-mono transition cursor-pointer ${
                    activeTestUrl === ep.exampleUrl
                      ? 'bg-neutral-800 text-white border-neutral-700 shadow-sm'
                      : 'bg-neutral-950/60 text-neutral-400 border-neutral-800 hover:text-neutral-200'
                  }`}
                >
                  {ep.name}
                </button>
              ))}
            </div>

            <div className="bg-neutral-950 rounded-xl p-4 border border-neutral-800/80 font-mono text-xs">
              <div className="flex items-center justify-between pb-3 border-b border-neutral-900 text-neutral-400">
                <span className="truncate max-w-[80%] text-neutral-300">
                  <span className="text-emerald-400 font-bold">GET</span> {activeTestUrl}
                </span>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => copyToClipboard(activeTestUrl, 'test-url')}
                    className="hover:text-white transition flex items-center gap-1 text-[11px]"
                    title="Copy full URL"
                  >
                    {copiedKey === 'test-url' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedKey === 'test-url' ? 'Copied' : 'Copy'}</span>
                  </button>
                  <a
                    href={activeTestUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="hover:text-white transition flex items-center gap-1 text-[11px]"
                    title="Open in new tab"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                    <span>Raw</span>
                  </a>
                </div>
              </div>

              <div className="pt-3 max-h-64 overflow-y-auto text-neutral-300">
                {testing ? (
                  <div className="py-8 text-center text-neutral-500 animate-pulse">
                    Executing high-speed query...
                  </div>
                ) : testResult ? (
                  <pre className="whitespace-pre-wrap leading-relaxed">
                    {JSON.stringify(testResult, null, 2)}
                  </pre>
                ) : (
                  <div className="py-8 text-center text-neutral-500">
                    Click "Test Latency" to benchmark response
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* API Endpoints Catalog */}
        <div className="mb-10">
          <h2 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
            <span>Available Endpoints</span>
          </h2>

          <div className="divide-y divide-neutral-900 rounded-2xl bg-neutral-900/30 border border-neutral-800/80 overflow-hidden">
            {ENDPOINTS.map((endpoint) => (
              <div
                key={endpoint.path}
                className="p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-neutral-900/50 transition"
              >
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="px-2 py-0.5 rounded text-[11px] font-mono font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                      {endpoint.method}
                    </span>
                    <span className="font-mono text-xs sm:text-sm font-semibold text-neutral-100">
                      {endpoint.path}
                    </span>
                  </div>
                  <p className="text-xs text-neutral-400">{endpoint.description}</p>
                </div>

                <div className="flex items-center gap-2 self-start sm:self-center shrink-0">
                  <button
                    onClick={() => copyToClipboard(endpoint.exampleUrl, endpoint.path)}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-neutral-950 border border-neutral-800 hover:border-neutral-700 text-xs font-mono text-neutral-300 transition cursor-pointer"
                  >
                    {copiedKey === endpoint.path ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                        <span className="text-emerald-400">Copied</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5 text-neutral-400" />
                        <span>Copy URL</span>
                      </>
                    )}
                  </button>

                  <a
                    href={endpoint.exampleUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-neutral-950 border border-neutral-800 hover:border-neutral-700 text-xs font-mono text-neutral-300 hover:text-white transition"
                  >
                    <ExternalLink className="w-3.5 h-3.5 text-neutral-400" />
                    <span>Open</span>
                  </a>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Allowed Domain Info Box */}
        <div className="p-5 rounded-2xl bg-neutral-900/20 border border-neutral-900 text-xs text-neutral-400 space-y-2">
          <div className="font-semibold text-neutral-200 flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>Authorized CORS Origin Whitelist</span>
          </div>
          <p>
            This API responds strictly to authorized cross-domain origins: <code className="text-neutral-300 bg-neutral-900 px-1 py-0.5 rounded">*.anaku.web.id</code>, <code className="text-neutral-300 bg-neutral-900 px-1 py-0.5 rounded">*.ytcat.web.id</code>, <code className="text-neutral-300 bg-neutral-900 px-1 py-0.5 rounded">*.fomo.web.id</code>, <code className="text-neutral-300 bg-neutral-900 px-1 py-0.5 rounded">*.gomuost.wapkizs.com</code>, <code className="text-neutral-300 bg-neutral-900 px-1 py-0.5 rounded">*.ostanime.pages.dev</code>, <code className="text-neutral-300 bg-neutral-900 px-1 py-0.5 rounded">*.ostanime.web.id</code>, Google Cloud Run, AI Studio, and local development.
          </p>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-neutral-900 py-6 px-6 text-center text-xs text-neutral-500">
        <p>Sonora YouTube Music API &bull; Running in High-Speed Mode &bull; Built with Express &amp; YouTubeI</p>
      </footer>
    </div>
  );
}
