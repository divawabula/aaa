import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import {defineConfig} from 'vite';

export default defineConfig(() => {
  return {
    plugins: [react(), tailwindcss()],
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
    server: {
      allowedHosts: [
        'anaku.web.id',
        '.anaku.web.id',
        'ytcat.web.id',
        '.ytcat.web.id',
        'fomo.web.id',
        '.fomo.web.id',
        'gomuost.wapkizs.com',
        '.gomuost.wapkizs.com',
        '.run.app',
        'aistudio.google',
        '.aistudio.google',
        '.google.com',
        'localhost',
        '127.0.0.1',
      ],
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      // Do not modify—file watching is disabled to prevent flickering during agent edits.
      hmr: process.env.DISABLE_HMR !== 'true',
      // Disable file watching when DISABLE_HMR is true to save CPU during agent edits.
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
