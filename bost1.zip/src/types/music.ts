export interface ArtistRef {
  id: string | null;
  name: string;
}

export interface SongItem {
  id: string;
  title: string;
  artist: string;
  artists: ArtistRef[];
  album: string;
  album_id: string | null;
  year: string;
  duration: string;
  duration_seconds: number;
  cover_art: string;
  thumbnails?: Array<{ url: string; width: number; height: number }>;
  lyrics?: string | null;
  lyrics_source?: string | null;
}

export interface ArtistDetail {
  id: string;
  name: string;
  cover_art: string;
  description: string | null;
  subscribers: string | null;
  total_songs: number;
}

export interface AlbumDetail {
  id: string;
  title: string;
  artist: string;
  artist_id?: string | null;
  artists?: ArtistRef[];
  year: string;
  cover_art: string;
  total_tracks: number;
}

export interface AlbumTrack {
  track_number: number;
  id: string;
  title: string;
  artist: string;
  artist_id?: string | null;
  artists?: ArtistRef[];
  album: string;
  album_id: string;
  year: string;
  duration: string;
  duration_seconds: number;
  cover_art: string;
}
