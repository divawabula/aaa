import express, { Request, Response, NextFunction } from 'express';
import cors from 'cors';
import compression from 'compression';
import path from 'path';
import { fileURLToPath } from 'url';
import { Innertube, UniversalCache, Log } from 'youtubei.js';

// Suppress non-breaking internal parser typecheck warning logs from YouTube's dynamic renderers
Log.setLevel(Log.Level.ERROR);

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const isProduction = process.env.NODE_ENV === 'production';
// AI Studio dev server supervisor requires port 3000
const PORT = isProduction ? Number(process.env.PORT || 3000) : 3000;
const SERVER_START_TIME = Date.now();

// High-speed In-Memory TTL Cache to deliver instant responses (< 5ms) for repeated queries
interface CacheEntry {
  data: any;
  expiresAt: number;
}
const cache = new Map<string, CacheEntry>();
const MAX_CACHE_ENTRIES = 1200;

function getCached(key: string): any | null {
  const entry = cache.get(key);
  if (!entry) return null;
  if (Date.now() > entry.expiresAt) {
    cache.delete(key);
    return null;
  }
  return entry.data;
}

function setCached(key: string, data: any, ttlSeconds: number): void {
  if (cache.size >= MAX_CACHE_ENTRIES) {
    // Prune oldest 150 entries when capacity is reached
    const iter = cache.keys();
    for (let i = 0; i < 150; i++) {
      const nextKey = iter.next().value;
      if (!nextKey) break;
      cache.delete(nextKey);
    }
  }
  cache.set(key, { data, expiresAt: Date.now() + ttlSeconds * 1000 });
}

// 1. Gzip & Deflate Compression middleware: reduces payload size by up to 85%
app.use(
  compression({
    level: 6, // Optimal tradeoff between CPU usage and compression ratio
    threshold: 1024, // Only compress responses > 1KB
  })
);

// 2. High-precision Response Time Header
app.use((req: Request, res: Response, next: NextFunction) => {
  const start = process.hrtime.bigint();
  res.on('finish', () => {
    const end = process.hrtime.bigint();
    const durationMs = Number(end - start) / 1_000_000;
    // Set header if headers not yet sent
    if (!res.headersSent) {
      res.setHeader('X-Response-Time', `${durationMs.toFixed(2)}ms`);
    }
  });
  next();
});

// Fast Whitelist Domain Checker
const ALLOWED_EXACT_HOSTS = new Set([
  'localhost',
  '127.0.0.1',
  'anaku.web.id',
  'ytcat.web.id',
  'fomo.web.id',
  'gomuost.wapkizs.com',
  'run.app',
  'aistudio.google',
]);

const ALLOWED_SUFFIXES = [
  '.anaku.web.id',
  '.ytcat.web.id',
  '.fomo.web.id',
  '.gomuost.wapkizs.com',
  '.run.app',
  '.aistudio.google',
  '.google.com',
  '.googleusercontent.com',
];

function isAllowedDomain(originOrHost?: string): boolean {
  if (!originOrHost) return true; // Direct browser URL navigation, curl, or server-to-server

  try {
    const raw = originOrHost.trim();
    let hostname = '';
    if (raw.startsWith('http://') || raw.startsWith('https://')) {
      hostname = new URL(raw).hostname.toLowerCase();
    } else {
      hostname = raw.toLowerCase().split(':')[0];
    }

    if (!hostname) return true;
    if (ALLOWED_EXACT_HOSTS.has(hostname)) return true;

    for (let i = 0; i < ALLOWED_SUFFIXES.length; i++) {
      if (hostname.endsWith(ALLOWED_SUFFIXES[i])) return true;
    }
  } catch {
    return false;
  }

  return false;
}

// CORS setup allowing authorized origins with preflight cache
app.use(
  cors({
    origin: (origin, callback) => {
      if (!origin || isAllowedDomain(origin)) {
        return callback(null, true);
      }
      return callback(null, false);
    },
    methods: ['GET', 'POST', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With'],
    credentials: true,
    maxAge: 86400, // 24 hours preflight cache
  })
);

app.use(express.json());

// Strict domain security middleware for /api endpoints
app.use('/api', (req: Request, res: Response, next: NextFunction) => {
  const origin = req.headers.origin as string | undefined;
  const referer = req.headers.referer as string | undefined;

  if (origin && !isAllowedDomain(origin)) {
    return res.status(403).json({
      error: 'Forbidden',
      message: `Akses ditolak: Domain '${origin}' tidak diizinkan mengakses API ini.`,
      allowed_domains: [
        'anaku.web.id (*.anaku.web.id)',
        'ytcat.web.id (*.ytcat.web.id)',
        'fomo.web.id (*.fomo.web.id)',
        'gomuost.wapkizs.com (*.gomuost.wapkizs.com)',
        '*.run.app, *.aistudio.google, *.google.com',
        'localhost, 127.0.0.1',
      ],
    });
  }

  if (referer && !origin && !isAllowedDomain(referer)) {
    return res.status(403).json({
      error: 'Forbidden',
      message: `Akses ditolak: Referer '${referer}' tidak diizinkan mengakses API ini.`,
      allowed_domains: [
        'anaku.web.id (*.anaku.web.id)',
        'ytcat.web.id (*.ytcat.web.id)',
        'fomo.web.id (*.fomo.web.id)',
        'gomuost.wapkizs.com (*.gomuost.wapkizs.com)',
        '*.run.app, *.aistudio.google, *.google.com',
        'localhost, 127.0.0.1',
      ],
    });
  }

  // Set HTTP caching headers for client / CDN caches
  res.setHeader('Cache-Control', 'public, max-age=180, s-maxage=3600, stale-while-revalidate=86400');
  next();
});

// Initialize YouTubeI Innertube singleton
let innertubeInstance: Innertube | null = null;
let initPromise: Promise<Innertube> | null = null;

async function getInnertube(): Promise<Innertube> {
  if (innertubeInstance) return innertubeInstance;
  if (!initPromise) {
    initPromise = Innertube.create({
      cache: new UniversalCache(false),
      generate_session_locally: true,
    })
      .then((yt) => {
        innertubeInstance = yt;
        console.log('[Sonora API] Innertube initialized successfully');
        return yt;
      })
      .catch((err) => {
        initPromise = null;
        console.error('[Sonora API] Failed to initialize Innertube:', err);
        throw err;
      });
  }
  return initPromise;
}

function cleanLh3Url(url?: string): string {
  if (!url) return '';
  return url.replace(/https?:\/\/[a-z0-9-]+\.googleusercontent\.com/i, 'https://lh3.googleusercontent.com');
}

// Cover art helper with high-resolution transformation
function resolveCoverArt(thumbnails: any[] = []): string {
  if (!thumbnails || !Array.isArray(thumbnails) || thumbnails.length === 0) {
    return 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=600&h=600&fit=crop';
  }

  const gThumb = thumbnails.find((t) => t?.url && t.url.includes('googleusercontent.com'));
  const candidate = gThumb || thumbnails[thumbnails.length - 1] || thumbnails[0];
  let url = candidate?.url || '';

  if (url.includes('googleusercontent.com')) {
    url = cleanLh3Url(url);
    if (url.includes('=w') || url.includes('=s')) {
      url = url.replace(/=w\d+-h\d+[^?&]*/, '=w600-h600-l90-rj').replace(/=s\d+[^?&]*/, '=s600');
    } else {
      url += '=w600-h600-l90-rj';
    }
  }

  return url;
}

// Extract year cleanly
function extractYear(item: any, albumObj?: any): string {
  if (item?.year) return String(item.year);
  if (albumObj?.year) return String(albumObj.year);

  if (item?.flex_columns && Array.isArray(item.flex_columns)) {
    for (const col of item.flex_columns) {
      const runs = col?.title?.runs || [];
      for (const run of runs) {
        const text = run?.text?.trim() || '';
        const match = text.match(/\b(19\d{2}|20\d{2})\b/);
        if (match) return match[1];
      }
    }
  }

  if (item?.subtitle?.runs && Array.isArray(item.subtitle.runs)) {
    for (const run of item.subtitle.runs) {
      const match = (run?.text || '').match(/\b(19\d{2}|20\d{2})\b/);
      if (match) return match[1];
    }
  }
  if (item?.subtitle?.text) {
    const match = item.subtitle.text.match(/\b(19\d{2}|20\d{2})\b/);
    if (match) return match[1];
  }

  return '2024';
}

// Robust album extractor
function extractAlbumInfo(item: any): { id: string | null; name: string; year?: string } {
  let albumInfo: { id: string | null; name: string; year?: string } | null = null;

  if (item?.album) {
    if (typeof item.album === 'object') {
      const name = item.album.name || item.album.title || item.album.text;
      const id = item.album.id || item.album.endpoint?.payload?.browseId || null;
      const year = item.album.year ? String(item.album.year) : undefined;
      if (name) {
        albumInfo = { id, name: String(name).trim(), year };
      }
    } else if (typeof item.album === 'string' && item.album.trim()) {
      albumInfo = { id: null, name: item.album.trim() };
    }
  }

  if (item?.flex_columns && Array.isArray(item.flex_columns)) {
    for (let c = 0; c < item.flex_columns.length; c++) {
      const col = item.flex_columns[c];
      const runs = col?.title?.runs || [];
      for (const run of runs) {
        const pageType = run?.endpoint?.payload?.browseEndpointContextSupportedConfigs?.browseEndpointContextMusicConfig?.pageType;
        const browseId = run?.endpoint?.payload?.browseId;
        if (
          pageType === 'MUSIC_PAGE_TYPE_ALBUM' ||
          (browseId && (browseId.startsWith('MPRE') || browseId.startsWith('OLAK5uy_')))
        ) {
          const runText = (run.text || '').trim();
          if (runText) {
            albumInfo = {
              id: browseId || albumInfo?.id || null,
              name: runText,
              year: albumInfo?.year,
            };
            break;
          }
        }
      }
      if (albumInfo?.name && albumInfo?.id) break;
    }
  }

  const menuItems = item?.menu?.items || [];
  const albumMenuItem = menuItems.find(
    (m: any) =>
      m?.icon_type === 'ALBUM' ||
      (typeof m?.text === 'string' && /album/i.test(m.text)) ||
      m?.endpoint?.payload?.browseEndpointContextSupportedConfigs?.browseEndpointContextMusicConfig?.pageType === 'MUSIC_PAGE_TYPE_ALBUM'
  );
  const menuAlbumBrowseId = albumMenuItem?.endpoint?.payload?.browseId || null;

  if (menuAlbumBrowseId) {
    if (albumInfo) {
      if (!albumInfo.id) {
        albumInfo.id = menuAlbumBrowseId;
      }
    } else {
      if (item?.flex_columns && Array.isArray(item.flex_columns)) {
        for (let c = 1; c < item.flex_columns.length; c++) {
          const col = item.flex_columns[c];
          const text = col?.title?.text || (col?.title?.runs?.map((r: any) => r.text).join('') || '').trim();
          if (
            text &&
            !/^\d+:\d+$/.test(text) &&
            !/\bplays\b/i.test(text) &&
            !/\b(19\d{2}|20\d{2})\b/.test(text)
          ) {
            const isArtist = col?.title?.runs?.some(
              (r: any) =>
                r?.endpoint?.payload?.browseEndpointContextSupportedConfigs?.browseEndpointContextMusicConfig?.pageType === 'MUSIC_PAGE_TYPE_ARTIST' ||
                r?.endpoint?.payload?.browseId?.startsWith('UC')
            );
            if (!isArtist) {
              albumInfo = { id: menuAlbumBrowseId, name: text };
              break;
            }
          }
        }
      }
    }
  }

  if (!albumInfo && item?.subtitle) {
    if (item.subtitle.runs && Array.isArray(item.subtitle.runs)) {
      for (const run of item.subtitle.runs) {
        const pageType = run?.endpoint?.payload?.browseEndpointContextSupportedConfigs?.browseEndpointContextMusicConfig?.pageType;
        const browseId = run?.endpoint?.payload?.browseId;
        if (
          pageType === 'MUSIC_PAGE_TYPE_ALBUM' ||
          (browseId && (browseId.startsWith('MPRE') || browseId.startsWith('OLAK5uy_')))
        ) {
          albumInfo = { id: browseId || null, name: (run.text || '').trim() };
          break;
        }
      }
    }
    if (!albumInfo && typeof item.subtitle.text === 'string') {
      const parts = item.subtitle.text.split(/\s*[•·]\s*/).map((p: string) => p.trim()).filter(Boolean);
      for (const part of parts) {
        if (
          !/^\d+:\d+$/.test(part) &&
          !/\bplays\b/i.test(part) &&
          !/\b(19\d{2}|20\d{2})\b/.test(part) &&
          part.toLowerCase() !== 'song' &&
          part.toLowerCase() !== 'video'
        ) {
          albumInfo = { id: menuAlbumBrowseId || null, name: part };
          break;
        }
      }
    }
  }

  return albumInfo || { id: menuAlbumBrowseId || null, name: 'Single' };
}

// Multi-artist extractor
function extractArtists(item: any): { artists: Array<{ id: string | null; name: string }>; artist: string } {
  const artistsList: Array<{ id: string | null; name: string }> = [];

  const addArtist = (name?: string, id: string | null = null) => {
    if (!name || typeof name !== 'string') return;
    const clean = name.trim();
    if (!clean || clean.toLowerCase() === 'unknown artist') return;
    if (!artistsList.some((a) => a.name.toLowerCase() === clean.toLowerCase())) {
      artistsList.push({ id: id || null, name: clean });
    }
  };

  if (Array.isArray(item?.artists) && item.artists.length > 0) {
    for (const a of item.artists) {
      if (typeof a === 'string') {
        addArtist(a);
      } else if (a && typeof a === 'object') {
        addArtist(a.name || a.text, a.channel_id || a.id);
      }
    }
  }

  if (item?.flex_columns && Array.isArray(item.flex_columns) && item.flex_columns.length > 1) {
    const col = item.flex_columns[1];
    const runs = col?.title?.runs || [];
    for (const run of runs) {
      const text = run?.text?.trim() || '';
      if (
        !text ||
        text === '•' ||
        text === '·' ||
        text === '&' ||
        /^\d+:\d+$/.test(text) ||
        /\bplays\b/i.test(text) ||
        /\b(19\d{2}|20\d{2})\b/.test(text)
      ) {
        continue;
      }
      const browseId = run?.endpoint?.payload?.browseId;
      const isArtist =
        browseId?.startsWith('UC') ||
        run?.endpoint?.payload?.browseEndpointContextSupportedConfigs?.browseEndpointContextMusicConfig?.pageType ===
          'MUSIC_PAGE_TYPE_ARTIST';
      if (isArtist) {
        addArtist(text, browseId || null);
      }
    }

    if (artistsList.length === 0) {
      let artistSegment = '';
      for (const run of runs) {
        const t = run?.text || '';
        if (t.includes('•') || t.includes('·')) break;
        artistSegment += t;
      }
      if (!artistSegment && col?.title?.text) {
        artistSegment = col.title.text.split(/\s*[•·]\s*/)[0] || '';
      }
      if (artistSegment && artistSegment.trim()) {
        artistSegment
          .split(/\s*(?:&|,|\bfeat\.?\b|\bft\.?\b|\band\b)\s*/i)
          .forEach((p) => addArtist(p));
      }
    }
  }

  const rawAuthor = item?.author || item?.authors;
  if (rawAuthor) {
    if (typeof rawAuthor === 'string') {
      const parts = rawAuthor.split(/\s*(?:&|,|\bfeat\.?\b|\bft\.?\b|\band\b)\s*/i);
      parts.forEach((p) => addArtist(p));
    } else if (Array.isArray(rawAuthor)) {
      rawAuthor.forEach((a) => {
        if (typeof a === 'string') addArtist(a);
        else if (a && typeof a === 'object') addArtist(a.name || a.text, a.channel_id || a.id);
      });
    } else if (typeof rawAuthor === 'object') {
      addArtist(rawAuthor.name || rawAuthor.text, rawAuthor.channel_id || rawAuthor.id);
    }
  }

  if (artistsList.length === 0 && item?.strapline_text_one?.text) {
    addArtist(item.strapline_text_one.text);
  }

  if (artistsList.length === 0 && item?.subtitle?.text) {
    const candidate = item.subtitle.text.split(/\s*[•·]\s*/)[0] || '';
    if (candidate) {
      candidate
        .split(/\s*(?:&|,|\bfeat\.?\b|\bft\.?\b|\band\b)\s*/i)
        .forEach((p: string) => addArtist(p));
    }
  }

  if (artistsList.length === 0) {
    artistsList.push({ id: null, name: 'Unknown Artist' });
  }

  const multiArtistString = artistsList.map((a) => a.name).filter(Boolean).join(', ');
  return {
    artists: artistsList,
    artist: multiArtistString || 'Unknown Artist',
  };
}

// Format standard Song item
function formatSongItem(item: any) {
  const thumbnails = item.thumbnail?.contents || (Array.isArray(item.thumbnail) ? item.thumbnail : []);
  const cover_art = resolveCoverArt(thumbnails);

  const { artists, artist } = extractArtists(item);
  const albumInfo = extractAlbumInfo(item);
  const year = extractYear(item, albumInfo);

  let durationText = '3:30';
  let durationSeconds = 210;
  if (item.duration) {
    if (typeof item.duration === 'string') {
      durationText = item.duration;
    } else if (item.duration.text) {
      durationText = item.duration.text;
      durationSeconds = item.duration.seconds || 0;
    }
  } else if (item.fixed_columns && Array.isArray(item.fixed_columns) && item.fixed_columns.length > 0) {
    const fc = item.fixed_columns[0]?.title?.text || item.fixed_columns[0]?.title?.runs?.[0]?.text;
    if (fc && /^\d+:\d+$/.test(fc.trim())) {
      durationText = fc.trim();
      const parts = durationText.split(':').map(Number);
      if (parts.length === 2) durationSeconds = parts[0] * 60 + parts[1];
      else if (parts.length === 3) durationSeconds = parts[0] * 3600 + parts[1] * 60 + parts[2];
    }
  }

  return {
    id: item.id || item.video_id,
    title: item.title?.text || item.title || item.name || 'Untitled Song',
    artist,
    artists,
    album: albumInfo.name,
    album_id: albumInfo.id,
    year,
    duration: durationText,
    duration_seconds: durationSeconds,
    cover_art,
    thumbnails: thumbnails.map((t: any) => ({
      url: cleanLh3Url(t.url),
      width: t.width,
      height: t.height,
    })),
  };
}

function getMusicVideoType(item: any): string | undefined {
  return (
    item?.endpoint?.payload?.watchEndpointMusicSupportedConfigs?.watchEndpointMusicConfig?.musicVideoType ||
    item?.overlay?.content?.endpoint?.payload?.watchEndpointMusicSupportedConfigs?.watchEndpointMusicConfig?.musicVideoType ||
    item?.endpoint?.payload?.watchEndpoint?.musicVideoType
  );
}

function isSongItem(item: any): boolean {
  if (!item) return false;

  if (item.item_type === 'video') return false;

  const mvt = getMusicVideoType(item);
  if (mvt === 'MUSIC_VIDEO_TYPE_OMV' || mvt === 'MUSIC_VIDEO_TYPE_UGC') {
    return false;
  }

  if (Array.isArray(item.badges)) {
    for (const b of item.badges) {
      const txt = (b?.label || b?.text || '').toLowerCase();
      if (txt === 'video' || txt === 'music video' || txt.includes('video')) return false;
    }
  }

  if (item.flex_columns && Array.isArray(item.flex_columns)) {
    for (const col of item.flex_columns) {
      const runs = col?.title?.runs || [];
      for (const r of runs) {
        const t = (r?.text || '').trim().toLowerCase();
        if (t === 'video' || t === 'music video') return false;
      }
    }
  }

  if (item.subtitle) {
    const sub = (typeof item.subtitle === 'string' ? item.subtitle : item.subtitle.text || '').toLowerCase();
    const parts = sub.split(/\s*[•·]\s*/).map((p: string) => p.trim());
    if (parts.includes('video') || parts.includes('music video')) return false;
  }

  const title = (item.title?.text || item.title || '').toLowerCase();
  if (mvt !== 'MUSIC_VIDEO_TYPE_ATV') {
    if (/\b(official music video|official video|official mv|\bm\/v\b|video klip|music video|lyric video)\b/i.test(title)) {
      return false;
    }
  }

  return true;
}

// -----------------------------------------------------------------------------
// High-Speed REST API Endpoints with In-Memory Caching and Compression
// -----------------------------------------------------------------------------

// Instant Health / Ping endpoint (< 1ms)
app.get('/api/ping', (req: Request, res: Response) => {
  res.setHeader('X-Cache', 'BYPASS');
  res.json({ pong: true, timestamp: Date.now() });
});

app.get('/api/health', (req: Request, res: Response) => {
  const uptimeSeconds = Math.floor((Date.now() - SERVER_START_TIME) / 1000);
  const mem = process.memoryUsage();
  res.setHeader('X-Cache', 'BYPASS');
  res.json({
    status: 'ok',
    message: 'API Running',
    uptime_seconds: uptimeSeconds,
    uptime_human: `${Math.floor(uptimeSeconds / 60)}m ${uptimeSeconds % 60}s`,
    cached_entries: cache.size,
    memory_heap_mb: (mem.heapUsed / 1024 / 1024).toFixed(2),
    timestamp: new Date().toISOString(),
  });
});

// API Directory
app.get('/api', (req: Request, res: Response) => {
  res.setHeader('X-Cache', 'HIT');
  res.json({
    status: 'API Running',
    name: 'Sonora High-Speed YouTube Music REST API',
    version: '2.0.0',
    description: 'High-performance, compressed, in-memory cached YouTube Music song and metadata API.',
    optimizations: [
      'Gzip/Deflate payload compression',
      'In-memory LRU TTL multi-tier cache',
      'Concurrent parallel upstream fetches',
      'Domain whitelist validation & 24h preflight cache',
    ],
    cors: 'Restricted to authorized domains',
    allowed_domains: [
      'anaku.web.id (*.anaku.web.id)',
      'ytcat.web.id (*.ytcat.web.id)',
      'fomo.web.id (*.fomo.web.id)',
      'gomuost.wapkizs.com (*.gomuost.wapkizs.com)',
      '*.run.app, *.aistudio.google, *.google.com',
      'localhost, 127.0.0.1',
    ],
    endpoints: {
      ping: '/api/ping',
      health: '/api/health',
      search: '/api/search?q={query}&limit={limit}',
      song: '/api/song/:id',
      artist: '/api/artist/:id',
      album: '/api/album/:id',
      home: '/api/home',
      lyrics: '/api/lyrics/:id',
    },
  });
});

// GET /api/search?q=...&limit=... (strictly song type, cached for 15 mins)
app.get('/api/search', async (req: Request, res: Response) => {
  const query = ((req.query.q as string) || '').trim();
  const limit = Math.min(parseInt((req.query.limit as string) || '20', 10), 50);

  if (!query) {
    return res.status(400).json({ error: 'Parameter "q" (search query) is required.' });
  }

  const cacheKey = `search:${query.toLowerCase()}:${limit}`;
  const cached = getCached(cacheKey);
  if (cached) {
    res.setHeader('X-Cache', 'HIT');
    return res.json(cached);
  }

  try {
    const yt = await getInnertube();
    const searchResult = await yt.music.search(query, { type: 'song' });
    let rawItems: any[] = [];
    if (searchResult.songs?.contents && Array.isArray(searchResult.songs.contents)) {
      rawItems = searchResult.songs.contents;
    } else if (Array.isArray(searchResult.contents)) {
      rawItems = searchResult.contents.filter((item: any) => (item?.id || item?.video_id) && item?.title);
    }

    let songItems = rawItems.filter(isSongItem);

    // Fallback if search returns empty and query looks like a YouTube video ID
    if (songItems.length === 0 && /^[a-zA-Z0-9_-]{11}$/.test(query)) {
      try {
        const upNext = await yt.music.getUpNext(query);
        if (upNext?.contents && upNext.contents.length > 0) {
          const first = upNext.contents[0];
          if (isSongItem(first)) {
            songItems = [first];
          }
        }
      } catch {}
    }

    const songs = songItems.slice(0, limit).map(formatSongItem);
    const responsePayload = {
      query,
      type: 'song',
      count: songs.length,
      songs,
    };

    // Cache search result for 15 minutes (900 seconds)
    setCached(cacheKey, responsePayload, 900);
    res.setHeader('X-Cache', 'MISS');
    res.json(responsePayload);
  } catch (error: any) {
    console.error('Search error:', error);
    res.status(500).json({
      error: 'Failed to search songs',
      message: error.message || String(error),
    });
  }
});

// GET /api/song/:id (Parallel fetching + 6 hours cache)
app.get('/api/song/:id', async (req: Request, res: Response) => {
  const songId = req.params.id;
  if (!songId) {
    return res.status(400).json({ error: 'Song ID is required' });
  }

  const cacheKey = `song:${songId}`;
  const cached = getCached(cacheKey);
  if (cached) {
    res.setHeader('X-Cache', 'HIT');
    return res.json(cached);
  }

  try {
    const yt = await getInnertube();

    // PERFORMANCE OPTIMIZATION: Fetch upNext and Lyrics in parallel using Promise.all
    const [upNextResult, lyricsResult] = await Promise.allSettled([
      yt.music.getUpNext(songId),
      yt.music.getLyrics(songId),
    ]);

    const upNext: any = upNextResult.status === 'fulfilled' ? upNextResult.value : null;
    const l: any = lyricsResult.status === 'fulfilled' ? lyricsResult.value : null;

    let lyricsData: { lyrics: string | null; footer: string | null } = { lyrics: null, footer: null };
    if (l?.description?.text) {
      lyricsData = {
        lyrics: l.description.text,
        footer: l.footer?.text || null,
      };
    }

    let currentSongFormatted: any = null;
    const relatedSongs: any[] = [];

    if (upNext?.contents && upNext.contents.length > 0) {
      const current = upNext.contents[0];
      const thumbs = current.thumbnail || [];
      const cover_art = resolveCoverArt(Array.isArray(thumbs) ? thumbs : [thumbs]);

      const { artists, artist } = extractArtists(current);
      const albumInfo = extractAlbumInfo(current);

      currentSongFormatted = {
        id: songId,
        title: current.title?.text || current.title || 'Untitled Song',
        artist,
        artists,
        album: albumInfo.name,
        album_id: albumInfo.id,
        year: albumInfo.year || current.year || extractYear(current, albumInfo),
        duration: current.duration?.text || '3:30',
        duration_seconds: current.duration?.seconds || 210,
        cover_art,
        thumbnails: (Array.isArray(thumbs) ? thumbs : []).map((t: any) => ({
          url: cleanLh3Url(t.url),
          width: t.width,
          height: t.height,
        })),
        lyrics: lyricsData.lyrics,
        lyrics_source: lyricsData.footer,
      };

      for (let i = 1; i < upNext.contents.length; i++) {
        const item = upNext.contents[i];
        const vid = item?.video_id || item?.id;
        if (!vid || vid === songId) continue;
        if (!isSongItem(item)) continue;

        const itemThumbs = item.thumbnail || [];
        const { artists: relArtists, artist: relArtist } = extractArtists(item);
        const relAlbumInfo = extractAlbumInfo(item);

        relatedSongs.push({
          id: vid,
          title: item.title?.text || item.title || 'Untitled Song',
          artist: relArtist,
          artists: relArtists,
          album: relAlbumInfo.name,
          album_id: relAlbumInfo.id,
          year: relAlbumInfo.year || item.year || extractYear(item, relAlbumInfo),
          duration: item.duration?.text || '3:30',
          duration_seconds: item.duration?.seconds || 210,
          cover_art: resolveCoverArt(Array.isArray(itemThumbs) ? itemThumbs : [itemThumbs]),
        });

        if (relatedSongs.length >= 16) break;
      }

      // Fast supplement if needed
      if (relatedSongs.length < 5 && currentSongFormatted?.artist && currentSongFormatted.artist !== 'Unknown Artist') {
        try {
          const suppResults = await yt.music.search(currentSongFormatted.artist, { type: 'song' });
          const suppItems = ((suppResults as any).songs?.contents || (suppResults as any).contents || []).filter(isSongItem);
          for (const sItem of suppItems) {
            const sid = (sItem as any)?.id || (sItem as any)?.video_id;
            if (sid && sid !== songId && !relatedSongs.some((r) => r.id === sid)) {
              relatedSongs.push(formatSongItem(sItem));
              if (relatedSongs.length >= 16) break;
            }
          }
        } catch {}
      }
    }

    if (!currentSongFormatted) {
      currentSongFormatted = {
        id: songId,
        title: 'Song ' + songId,
        artist: 'Unknown Artist',
        artists: [{ id: null, name: 'Unknown Artist' }],
        album: 'Single',
        album_id: null,
        year: '2024',
        duration: '3:30',
        duration_seconds: 210,
        cover_art: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=600&h=600&fit=crop',
        thumbnails: [],
        lyrics: lyricsData.lyrics,
        lyrics_source: lyricsData.footer,
      };
    }

    const payload = {
      song: currentSongFormatted,
      related_songs: relatedSongs,
    };

    // Cache song metadata for 6 hours (21600 seconds)
    setCached(cacheKey, payload, 21600);
    res.setHeader('X-Cache', 'MISS');
    res.json(payload);
  } catch (error: any) {
    console.error('Song detail error:', error);
    res.status(500).json({
      error: 'Failed to retrieve song details',
      message: error.message || String(error),
    });
  }
});

// GET /api/artist/:id (strictly song catalog, cached for 3 hours)
app.get('/api/artist/:id', async (req: Request, res: Response) => {
  const artistId = req.params.id;
  if (!artistId) {
    return res.status(400).json({ error: 'Artist ID is required' });
  }

  const cacheKey = `artist:${artistId}`;
  const cached = getCached(cacheKey);
  if (cached) {
    res.setHeader('X-Cache', 'HIT');
    return res.json(cached);
  }

  try {
    const yt = await getInnertube();
    const artistData = await yt.music.getArtist(artistId);

    const header: any = artistData.header;
    const headerThumbs = header?.thumbnail?.contents || header?.thumbnails || [];
    const cover_art = resolveCoverArt(headerThumbs);
    const artistName = header?.title?.text || header?.title || 'Unknown Artist';
    const description = header?.description?.text || null;
    const subscribers = header?.subscription_button?.subscribe_accessibility_label || null;

    const songsMap = new Map<string, any>();

    const sections = (artistData.sections || []) as any[];
    const songsShelf = sections.find((s: any) => {
      const title = (s.title?.text || s.title || '').toLowerCase();
      return title.includes('song') || title.includes('lagu') || title.includes('track');
    });

    if (songsShelf) {
      if (Array.isArray(songsShelf.contents)) {
        songsShelf.contents.forEach((item: any) => {
          if ((item?.id || item?.video_id) && isSongItem(item)) {
            const formatted = formatSongItem(item);
            songsMap.set(formatted.id, formatted);
          }
        });
      }

      const browseId = songsShelf.endpoint?.payload?.browseId;
      if (browseId) {
        try {
          const playlistId = browseId.replace(/^VL/, '');
          const pl = await yt.music.getPlaylist(playlistId);
          if (pl?.items && Array.isArray(pl.items)) {
            pl.items.forEach((item: any) => {
              if ((item?.id || item?.video_id) && isSongItem(item)) {
                const formatted = formatSongItem(item);
                if (!formatted.artist || formatted.artist === 'Unknown Artist') {
                  formatted.artist = artistName;
                  formatted.artists = [{ id: artistId, name: artistName }];
                }
                songsMap.set(formatted.id, formatted);
              }
            });
          }
        } catch {}
      }
    }

    if (songsMap.size < 10) {
      try {
        const searchResults = await yt.music.search(artistName, { type: 'song' });
        const found = (searchResults.songs?.contents || searchResults.contents || []).filter(isSongItem);
        found.forEach((item: any) => {
          const formatted = formatSongItem(item);
          const matches = formatted.artists.some(
            (a: any) => (a.id && a.id === artistId) || a.name.toLowerCase().includes(artistName.toLowerCase())
          );
          if (matches && !songsMap.has(formatted.id)) {
            songsMap.set(formatted.id, formatted);
          }
        });
      } catch {}
    }

    const allSongs = Array.from(songsMap.values());
    const payload = {
      artist: {
        id: artistId,
        name: artistName,
        cover_art,
        description,
        subscribers,
        total_songs: allSongs.length,
      },
      songs: allSongs,
    };

    // Cache artist catalog for 3 hours (10800 seconds)
    setCached(cacheKey, payload, 10800);
    res.setHeader('X-Cache', 'MISS');
    res.json(payload);
  } catch (error: any) {
    console.error('Artist error:', error);
    res.status(500).json({
      error: 'Failed to retrieve artist song catalog',
      message: error.message || String(error),
    });
  }
});

// GET /api/album/:id (cached for 6 hours)
app.get('/api/album/:id', async (req: Request, res: Response) => {
  const albumId = req.params.id;
  if (!albumId) {
    return res.status(400).json({ error: 'Album ID is required' });
  }

  const cacheKey = `album:${albumId}`;
  const cached = getCached(cacheKey);
  if (cached) {
    res.setHeader('X-Cache', 'HIT');
    return res.json(cached);
  }

  try {
    const yt = await getInnertube();
    const albumData = await yt.music.getAlbum(albumId);

    const header: any = albumData.header;
    const albumTitle = header?.title?.text || header?.title || 'Unknown Album';

    const albumArtists: Array<{ id: string | null; name: string }> = [];

    if (header?.strapline_text_one?.runs && Array.isArray(header.strapline_text_one.runs)) {
      header.strapline_text_one.runs.forEach((run: any) => {
        const text = (run?.text || '').trim();
        if (!text || text === '&' || text === ',' || text === '•' || text === '·') return;
        const browseId = run?.endpoint?.payload?.browseId || null;
        if (!albumArtists.some((a) => a.name.toLowerCase() === text.toLowerCase())) {
          albumArtists.push({ id: browseId, name: text });
        }
      });
    }

    if (albumArtists.length === 0 && header?.strapline_text_one?.endpoint?.payload?.browseId) {
      albumArtists.push({
        id: header.strapline_text_one.endpoint.payload.browseId,
        name: header.strapline_text_one.text || 'Unknown Artist',
      });
    }

    if (albumArtists.length === 0) {
      const rawAuthor = header?.author || header?.strapline_text_one?.text;
      if (typeof rawAuthor === 'string') {
        rawAuthor.split(/\s*(?:&|,|\bfeat\.?\b|\bft\.?\b|\band\b)\s*/i).forEach((name: string) => {
          const clean = name.trim();
          if (clean && !albumArtists.some((a) => a.name.toLowerCase() === clean.toLowerCase())) {
            albumArtists.push({ id: null, name: clean });
          }
        });
      } else if (rawAuthor && typeof rawAuthor === 'object') {
        albumArtists.push({
          id: rawAuthor.channel_id || rawAuthor.id || null,
          name: rawAuthor.name || rawAuthor.text || 'Unknown Artist',
        });
      }
    }

    const primaryArtistId = albumArtists.find((a) => a.id)?.id || null;
    const albumArtistString =
      albumArtists.map((a) => a.name).join(', ') || header?.strapline_text_one?.text || 'Unknown Artist';

    let year = '2024';
    if (header?.subtitle?.text) {
      const match = header.subtitle.text.match(/\b(19\d{2}|20\d{2})\b/);
      if (match) year = match[1];
    } else if (header?.subtitle?.runs) {
      for (const run of header.subtitle.runs) {
        const match = (run.text || '').match(/\b(19\d{2}|20\d{2})\b/);
        if (match) {
          year = match[1];
          break;
        }
      }
    }

    const headerThumbs = header?.thumbnail?.contents || header?.thumbnails || [];
    const cover_art = resolveCoverArt(headerThumbs);

    const tracks: any[] = [];
    const rawTracks = albumData.contents || [];

    rawTracks.forEach((t: any, index: number) => {
      const trackId = t.id || t.video_id;
      if (!trackId) return;

      const trackThumbs = t.thumbnail?.contents || headerThumbs;
      let durationText = '3:00';
      let durationSeconds = 180;
      if (t.duration) {
        durationText = typeof t.duration === 'string' ? t.duration : t.duration.text || '3:00';
        durationSeconds = typeof t.duration === 'object' ? t.duration.seconds || 180 : 180;
      }

      const trackArtists: Array<{ id: string | null; name: string }> = [];
      if (t.artists && Array.isArray(t.artists)) {
        t.artists.forEach((a: any) => {
          const name = (a.name || a.text || '').trim();
          if (name && !trackArtists.some((existing) => existing.name.toLowerCase() === name.toLowerCase())) {
            trackArtists.push({ id: a.channel_id || a.id || null, name });
          }
        });
      }
      if (trackArtists.length === 0) {
        albumArtists.forEach((aa) => {
          trackArtists.push({ id: aa.id, name: aa.name });
        });
      }
      trackArtists.forEach((ta) => {
        if (!ta.id) {
          const match = albumArtists.find((aa) => aa.name.toLowerCase() === ta.name.toLowerCase());
          if (match?.id) ta.id = match.id;
        }
      });

      const trackArtistString = trackArtists.map((a) => a.name).filter(Boolean).join(', ') || albumArtistString;
      const trackArtistId = trackArtists.find((ta) => ta.id)?.id || primaryArtistId || null;

      tracks.push({
        track_number: index + 1,
        id: trackId,
        title: t.title?.text || t.title || `Track ${index + 1}`,
        artist: trackArtistString,
        artist_id: trackArtistId,
        artists: trackArtists,
        album: albumTitle,
        album_id: albumId,
        year,
        duration: durationText,
        duration_seconds: durationSeconds,
        cover_art: resolveCoverArt(trackThumbs),
      });
    });

    const payload = {
      album: {
        id: albumId,
        title: albumTitle,
        artist: albumArtistString,
        artist_id: primaryArtistId,
        artists: albumArtists,
        year,
        cover_art,
        total_tracks: tracks.length,
      },
      tracks,
    };

    // Cache album for 6 hours (21600 seconds)
    setCached(cacheKey, payload, 21600);
    res.setHeader('X-Cache', 'MISS');
    res.json(payload);
  } catch (error: any) {
    console.error('Album error:', error);
    res.status(500).json({
      error: 'Failed to retrieve album details',
      message: error.message || String(error),
    });
  }
});

// GET /api/home (cached for 30 minutes)
app.get('/api/home', async (req: Request, res: Response) => {
  const cacheKey = 'home:curated';
  const cached = getCached(cacheKey);
  if (cached) {
    res.setHeader('X-Cache', 'HIT');
    return res.json(cached);
  }

  try {
    const yt = await getInnertube();
    // Run searches in parallel
    const [topHits, viralSongs] = await Promise.all([
      yt.music.search('Top Global Hits 2024', { type: 'song' }).catch(() => ({ songs: { contents: [] } })),
      yt.music.search('Viral Pop Songs', { type: 'song' }).catch(() => ({ songs: { contents: [] } })),
    ]);

    const hitsRaw = ((topHits as any).songs?.contents || (topHits as any).contents || []).filter(isSongItem);
    const viralRaw = ((viralSongs as any).songs?.contents || (viralSongs as any).contents || []).filter(isSongItem);

    const featuredSongs = hitsRaw.slice(0, 12).map(formatSongItem);
    const trendingSongs = viralRaw.slice(0, 12).map(formatSongItem);

    const payload = {
      featured: featuredSongs,
      trending: trendingSongs,
    };

    // Cache home feed for 30 minutes (1800 seconds)
    setCached(cacheKey, payload, 1800);
    res.setHeader('X-Cache', 'MISS');
    res.json(payload);
  } catch (error: any) {
    console.error('Home error:', error);
    res.status(500).json({
      error: 'Failed to fetch home songs',
      message: error.message || String(error),
    });
  }
});

// GET /api/lyrics/:id (cached for 6 hours)
app.get('/api/lyrics/:id', async (req: Request, res: Response) => {
  const songId = req.params.id;
  const cacheKey = `lyrics:${songId}`;
  const cached = getCached(cacheKey);
  if (cached) {
    res.setHeader('X-Cache', 'HIT');
    return res.json(cached);
  }

  try {
    const yt = await getInnertube();
    const l = await yt.music.getLyrics(songId);
    if (!l?.description?.text) {
      return res.status(404).json({ error: 'Lyrics not found for this song' });
    }
    const payload = {
      song_id: songId,
      lyrics: l.description.text,
      footer: l.footer?.text || null,
    };

    setCached(cacheKey, payload, 21600);
    res.setHeader('X-Cache', 'MISS');
    res.json(payload);
  } catch (error: any) {
    res.status(500).json({ error: 'Failed to fetch lyrics', message: error.message });
  }
});

// -----------------------------------------------------------------------------
// Vite middleware for dev / Static file serve for prod
// -----------------------------------------------------------------------------
async function startServer() {
  if (!isProduction) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[Sonora API] Server running on http://0.0.0.0:${PORT}`);
    // Pre-warm Innertube singleton in background so first incoming request has 0 initial boot latency
    getInnertube()
      .then(async (yt) => {
        console.log('[Sonora API] Pre-warming Innertube session in background...');
        await yt.music.search('top hits', { type: 'song' }).catch(() => {});
        console.log('[Sonora API] Pre-warming complete, ready for instant requests.');
      })
      .catch(() => {});
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
});
